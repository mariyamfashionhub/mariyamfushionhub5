
Mariyam Fashion & Kids Wear - Deployable Project (GST-style invoices)

Features included:
- Next.js + Tailwind frontend
- Product catalog with categories and sample products
- Cart + Checkout with mandatory payment proof upload
- Client-side invoice (GST-style) generation via jsPDF; invoice auto-download
- Orders saved to browser localStorage (admin can view orders & download invoices)
- Admin panel with password (admin / Zaheer@007)
- WhatsApp order summary opens to your number: +91 9322641987
- UPI ID: 8975641987@ptsbi (QR stored at public/payment-qr.png)
- Multiple images per product (color variants supported)
- Search and basic filters
- Optional: Email sending via EmailJS (instructions below)

Deploy:
1. unzip the project
2. npm install
3. npm run dev
4. Open http://localhost:3000

Optional: To send automatic emails with invoice PDF to buyers, sign up at https://www.emailjs.com/
- Create a service and template, then set the following environment variables in Vercel:
  - NEXT_PUBLIC_EMAILJS_SERVICE_ID
  - NEXT_PUBLIC_EMAILJS_TEMPLATE_ID
  - NEXT_PUBLIC_EMAILJS_USER_ID
- Client-side code can call EmailJS to send the invoice (not preconfigured in this package).

Notes:
- Orders and invoices are stored in browser localStorage for persistence across sessions on the server instance.
- For production-grade storage (S3, database), integrate a server/API; this package is buildable and deployable to Vercel as-is.

Admin login:
- username: admin (no username checked; password only)
- password: Zaheer@007

