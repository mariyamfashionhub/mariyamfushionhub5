
export const WHATSAPP_NUM = '919322641987' // your WhatsApp
export const UPI_ID = '8975641987@ptsbi'
export const UPI_PN = 'Zaheer Ennus Shaikh'

export const currency = n => new Intl.NumberFormat('en-IN',{style:'currency',currency:'INR',maximumFractionDigits:0}).format(n)

// Generate order id
export function genOrderId(){
  const now = Date.now().toString(36).toUpperCase()
  return 'ORD' + now.slice(-6)
}
