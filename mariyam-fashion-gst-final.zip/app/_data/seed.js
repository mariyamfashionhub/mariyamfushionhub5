
export const SEED = [
  {
    id: "MF1001",
    name: "Rose Gold Bridal Lehenga",
    price: 7999,
    compareAt: 9999,
    rating: 4.7,
    category: "Lehenga",
    colors: [
      {name: "Rose Gold", image: "https://images.unsplash.com/photo-1612336307429-8ff3a54c9a5d?q=80&w=1200&auto=format&fit=crop"},
      {name: "Maroon", image: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?q=80&w=1200&auto=format&fit=crop"}
    ],
    sizes: ["S","M","L","XL"],
    description: "Hand-embroidered lehenga with lightweight dupatta."
  },
  {
    id: "MF1002",
    name: "Peach Princess Frock (Kids)",
    price: 1299,
    compareAt: 1499,
    rating: 4.6,
    category: "Kids Wear",
    colors: [
      {name:"Peach", image: "https://images.unsplash.com/photo-1555529771-35a38fb4f7f9?q=80&w=1200&auto=format&fit=crop"}
    ],
    sizes: ["2-4Y","4-6Y","6-8Y"],
    description: "Soft cotton frock for parties and festivals."
  },
  {
    id: "MF1003",
    name: "Unisex Graphic Tee – Skyline",
    price: 799,
    compareAt: 999,
    rating: 4.3,
    category: "T-Shirts",
    colors: [
      {name:"Black", image:"https://images.unsplash.com/photo-1520975916090-3105956dac38?q=80&w=1200&auto=format&fit=crop"},
      {name:"White", image:"https://images.unsplash.com/photo-1541099649105-f69ad21f3246?q=80&w=1200&auto=format&fit=crop"}
    ],
    sizes: ["S","M","L","XL"],
    description: "Comfortable cotton t-shirt with skyline print."
  }
]
