
'use client'
import { useEffect, useState } from 'react'
import { SEED } from '../_data/seed'

export default function Admin(){
  const [logged, setLogged] = useState(false)
  const [password, setPassword] = useState('')
  const [products, setProducts] = useState([])
  const [orders, setOrders] = useState([])
  const [editing, setEditing] = useState(null)

  useEffect(()=>{
    const saved = localStorage.getItem('mf_products')
    setProducts(saved? JSON.parse(saved) : SEED)
    const o = localStorage.getItem('mf_orders')
    setOrders(o? JSON.parse(o) : [])
  },[])

  function login(e){
    e.preventDefault()
    if(password==='Zaheer@007'){ setLogged(true) }
    else alert('Wrong password')
  }

  function saveProducts(next){
    setProducts(next); localStorage.setItem('mf_products', JSON.stringify(next)); alert('Saved')
  }

  function newProduct(){
    const id = 'MF' + (Math.floor(Math.random()*9000)+1000)
    setEditing({id,name:'',price:0,compareAt:0,category:'Lehenga',colors:[],sizes:[],description:''})
  }

  function saveEditing(){
    if(!editing.id){ alert('ID required'); return }
    const exists = products.some(p=>p.id===editing.id)
    const next = exists? products.map(p=>p.id===editing.id?editing:p) : [editing,...products]
    saveProducts(next); setEditing(null)
  }

  function deleteProduct(id){
    if(!confirm('Delete product?')) return
    const next = products.filter(p=>p.id!==id); saveProducts(next)
  }

  return (
    <div className="max-w-6xl mx-auto p-4">
      {!logged ? (
        <form onSubmit={login} className="max-w-md mx-auto mt-20 bg-white p-4 rounded">
          <h2 className="text-xl font-bold">Admin Login</h2>
          <input type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="Password" className="w-full border p-2 mt-2" />
          <button className="mt-3 px-4 py-2 bg-black text-white rounded">Login</button>
        </form>
      ) : (
        <div>
          <h1 className="text-2xl font-bold">Admin Panel</h1>
          <div className="mt-3 flex gap-2">
            <button onClick={newProduct} className="px-3 py-2 bg-black text-white rounded">+ New Product</button>
            <a href="/" className="ml-auto underline">Back to Store</a>
          </div>

          <h2 className="mt-6 font-semibold">Products</h2>
          <table className="w-full text-sm mt-2">
            <thead><tr className="border-b"><th>Name</th><th>Price</th><th>Category</th><th></th></tr></thead>
            <tbody>
              {products.map(p=> <tr key={p.id} className="border-b"><td className="py-2">{p.name}</td><td>₹{p.price}</td><td>{p.category}</td><td className="text-right"><button onClick={()=>setEditing({...p})} className="px-2 py-1 border rounded mr-2">Edit</button><button onClick={()=>deleteProduct(p.id)} className="px-2 py-1 border rounded">Delete</button></td></tr>)}
            </tbody>
          </table>

          <h2 className="mt-6 font-semibold">Orders</h2>
          <table className="w-full text-sm mt-2">
            <thead><tr className="border-b"><th>Order ID</th><th>Name</th><th>Amount</th><th>Status</th><th></th></tr></thead>
            <tbody>
              {orders.map(o=> <tr key={o.id} className="border-b"><td className="py-2">{o.id}</td><td>{o.customer.name}</td><td>{o.total}</td><td>{o.status}</td><td className="text-right"><a href={o.invoice} download className="px-2 py-1 border rounded mr-2">Download Bill</a></td></tr>)}
            </tbody>
          </table>

          {editing && (
            <div className="fixed inset-0 z-50 flex items-center justify-center">
              <div className="absolute inset-0 bg-black/50" onClick={()=>setEditing(null)} />
              <div className="relative bg-white p-4 rounded w-[95vw] max-w-2xl">
                <h3 className="font-semibold">{editing.id? 'Edit' : 'New'} Product</h3>
                <div className="grid md:grid-cols-2 gap-2 mt-2">
                  <input value={editing.id} onChange={e=>setEditing({...editing,id:e.target.value})} className="p-2 border" placeholder="ID" />
                  <input value={editing.name} onChange={e=>setEditing({...editing,name:e.target.value})} className="p-2 border" placeholder="Name" />
                  <input type="number" value={editing.price} onChange={e=>setEditing({...editing,price:Number(e.target.value)})} className="p-2 border" placeholder="Price" />
                  <input type="number" value={editing.compareAt} onChange={e=>setEditing({...editing,compareAt:Number(e.target.value)})} className="p-2 border" placeholder="Compare At" />
                  <input value={editing.category} onChange={e=>setEditing({...editing,category:e.target.value})} className="p-2 border" placeholder="Category" />
                  <input value={editing.rating} onChange={e=>setEditing({...editing,rating:Number(e.target.value)})} className="p-2 border" placeholder="Rating" />
                  <input value={editing.description} onChange={e=>setEditing({...editing,description:e.target.value})} className="p-2 border col-span-2" placeholder="Description" />
                </div>
                <div className="mt-2 flex gap-2">
                  <button onClick={saveEditing} className="px-3 py-2 bg-black text-white rounded">Save</button>
                  <button onClick={()=>setEditing(null)} className="px-3 py-2 border rounded">Cancel</button>
                </div>
              </div>
            </div>
          )}

        </div>
      )}
    </div>
  )
}
