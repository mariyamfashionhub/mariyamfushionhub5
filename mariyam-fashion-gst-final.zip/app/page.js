
'use client'
import { useEffect, useMemo, useState } from 'react'
import { SEED } from './_data/seed'
import { currency, WHATSAPP_NUM, UPI_ID, genOrderId } from './_utils/shop'
import { jsPDF } from 'jspdf'

export default function Page(){
  const [products, setProducts] = useState([])
  const [query,setQuery] = useState('')
  const [category,setCategory] = useState('All')
  const [min,setMin] = useState('')
  const [max,setMax] = useState('')
  const [cart,setCart] = useState([])
  const [drawer,setDrawer] = useState(false)
  const [showUPI,setShowUPI] = useState(false)
  const [checkoutOpen,setCheckoutOpen] = useState(false)
  const [customer,setCustomer] = useState({name:'',email:'',phone:'',address:''})
  const [paymentProof,setPaymentProof] = useState(null)

  useEffect(()=>{
    const saved = localStorage.getItem('mf_products')
    setProducts(saved? JSON.parse(saved) : SEED)
    const c = localStorage.getItem('mf_cart')
    if(c) setCart(JSON.parse(c))
  },[])
  useEffect(()=>localStorage.setItem('mf_cart', JSON.stringify(cart)),[cart])

  const filtered = useMemo(()=>{
    let list = (products||[]).filter(p => p.name.toLowerCase().includes(query.toLowerCase()) || p.category.toLowerCase().includes(query.toLowerCase()))
    if(category!=='All') list = list.filter(p => p.category===category)
    if(min) list = list.filter(p => p.price >= Number(min))
    if(max) list = list.filter(p => p.price <= Number(max))
    return list
  },[products,query,category,min,max])

  const addToCart = (p, color, size) => {
    const s = size || p.sizes?.[0] || 'Free'
    const key = `${p.id}-${color || p.colors?.[0]?.name || 'Default'}-${s}`
    setCart(prev => {
      const found = prev.find(i => i.key===key)
      if(found) return prev.map(i => i.key===key ? {...i, qty: i.qty+1} : i)
      return [...prev, { key, id:p.id, name:p.name, price:p.price, color: color || p.colors?.[0]?.name, size: s, image: p.colors?.[0]?.image, qty:1 }]
    })
    setDrawer(true)
  }

  const subtotal = cart.reduce((s,i)=>s+i.price*i.qty,0)

  function handleFile(e){
    const file = e.target.files[0]
    if(!file) return
    const reader = new FileReader()
    reader.onload = ()=> setPaymentProof(reader.result)
    reader.readAsDataURL(file)
  }

  function generateInvoicePDF(order){
    const doc = new jsPDF()
    doc.setFontSize(16)
    doc.text('Mariyam Fashion and Kids Wear', 14, 20)
    doc.setFontSize(10)
    doc.text('Invoice / Tax Invoice', 14, 28)
    doc.text(`Order ID: ${order.id}`, 14, 36)
    doc.text(`Date: ${new Date(order.date).toLocaleString()}`, 14, 42)
    doc.text(`Customer: ${order.customer.name}`, 14, 50)
    doc.text(`Phone: ${order.customer.phone}`, 14, 56)
    doc.text(`Address: ${order.customer.address}`, 14, 62)

    let y = 80
    doc.text('Items:', 14, y)
    order.items.forEach((it, idx) => {
      y += 8
      doc.text(`${idx+1}. ${it.name} (${it.color}) x ${it.qty} - ${it.size}`, 14, y)
      doc.text(`${currency(it.price * it.qty)}`, 160, y)
    })
    y += 12
    doc.text(`Subtotal: ${currency(order.total)}`, 14, y)
    y += 8
    doc.text('Payment Method: UPI', 14, y)
    y += 8
    doc.text('UPI ID: ' + order.upi, 14, y)
    // Footer
    doc.setFontSize(9)
    doc.text('Thank you for shopping at Mariyam Fashion!', 14, 280)
    const pdfBlob = doc.output('blob')
    // return base64 data url
    return new Promise(resolve => {
      const reader = new FileReader()
      reader.onload = ()=> resolve(reader.result)
      reader.readAsDataURL(pdfBlob)
    })
  }

  async function confirmOrder(e){
    e.preventDefault()
    if(!customer.name || !customer.email || !customer.address || !customer.phone){ alert('Please fill all customer details'); return }
    if(!paymentProof){ alert('Please upload payment proof (mandatory)'); return }
    const order = {
      id: genOrderId(),
      date: Date.now(),
      customer,
      items: cart,
      total: subtotal,
      upi: UPI_ID,
      paymentProof,
      status: 'Paid'
    }
    const pdfDataUrl = await generateInvoicePDF(order)
    order.invoice = pdfDataUrl
    // save to localStorage orders list
    const saved = JSON.parse(localStorage.getItem('mf_orders')||'[]')
    saved.unshift(order)
    localStorage.setItem('mf_orders', JSON.stringify(saved))
    // send email via EmailJS? (optional) - instructions in README
    // open whatsapp with summary
    const lines = order.items.map(i => `• ${i.name} - ${i.color} x ${i.qty} (${i.size}) - ${currency(i.price*i.qty)}`).join('%0A')
    const waMsg = encodeURIComponent(`New Order ${order.id}%0AName: ${order.customer.name}%0APhone: ${order.customer.phone}%0AEmail: ${order.customer.email}%0AAddress: ${order.customer.address}%0A%0AItems:%0A${lines}%0A%0ASubtotal: ${currency(order.total)}%0AInvoice: (sent to buyer email)`)
    window.open(`https://wa.me/${WHATSAPP_NUM}?text=${waMsg}`, '_blank')
    // allow user to download invoice
    const link = document.createElement('a')
    link.href = order.invoice
    link.download = `${order.id}.pdf`
    link.click()
    // clear cart
    setCart([]); localStorage.removeItem('mf_cart')
    setCheckoutOpen(false); setDrawer(false)
    alert('Order placed! Invoice downloaded and order saved in admin orders.')
  }

  return (
    <div className="min-h-screen">
      <header className="sticky top-0 z-30 bg-white/70 border-b">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center gap-3">
          <div className="text-xl font-bold">Mariyam Fashion and Kids Wear</div>
          <nav className="ml-6 flex gap-3">
            {['All','Lehenga','Kids Wear','T-Shirts'].map(c=> <button key={c} onClick={()=>setCategory(c)} className={`px-3 py-1 ${category===c?'bg-black text-white rounded':'rounded'}`}>{c}</button>)}
          </nav>
          <div className="ml-auto flex items-center gap-2">
            <input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search..." className="h-10 rounded px-3 border" />
            <button onClick={()=>setDrawer(true)} className="h-10 px-3 rounded border">Cart ({cart.reduce((s,i)=>s+i.qty,0)})</button>
            <a href="/admin" className="ml-3 underline">Admin</a>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-6">
        <div className="grid md:grid-cols-3 gap-6">
          {filtered.map(p => (
            <div key={p.id} className="bg-white rounded-2xl p-3 shadow">
              <img src={p.colors?.[0]?.image} className="w-full h-56 object-cover rounded" alt={p.name} />
              <h3 className="mt-2 font-semibold">{p.name}</h3>
              <div className="text-sm text-slate-600">{p.category}</div>
              <div className="mt-2 flex items-center justify-between">
                <div><b>{currency(p.price)}</b><div className="text-xs line-through text-slate-400">{currency(p.compareAt)}</div></div>
                <div className="text-sm bg-slate-100 px-2 rounded">{p.rating}★</div>
              </div>
              <div className="mt-3 grid grid-cols-2 gap-2">
                <button onClick={()=>addToCart(p, p.colors?.[0]?.name, p.sizes?.[0])} className="px-3 py-2 rounded border">Add</button>
                <a href={`/product/${p.id}`} className="px-3 py-2 rounded bg-black text-white text-center">View</a>
              </div>
            </div>
          ))}
        </div>
      </main>

      {/* Cart Drawer */}
      <div className={`fixed right-0 top-16 w-[95vw] sm:w-[420px] bg-white border-l p-4 shadow ${drawer?'translate-x-0':'translate-x-full'}`}>
        <div className="flex items-center justify-between"><div className="font-semibold">Your Cart</div><button onClick={()=>setDrawer(false)}>Close</button></div>
        <div className="mt-3 space-y-3 max-h-[60vh] overflow-auto">
          {cart.length===0 && <div className="text-slate-500">Cart is empty.</div>}
          {cart.map(i=> (
            <div key={i.key} className="flex gap-3 items-center">
              <img src={i.image} className="h-16 w-16 object-cover rounded" />
              <div className="flex-1">
                <div className="font-medium">{i.name}</div>
                <div className="text-sm text-slate-500">{i.color} • {i.size}</div>
                <div className="mt-1 text-sm">{currency(i.price)} x {i.qty}</div>
              </div>
              <div className="text-right">
                <div className="font-semibold">{currency(i.price * i.qty)}</div>
              </div>
            </div>
          ))}
        </div>
        <div className="mt-3">
          <div className="flex items-center justify-between"><div>Subtotal</div><div className="font-bold">{currency(subtotal)}</div></div>
          <div className="mt-3 grid gap-2">
            <button onClick={()=>{ if(cart.length===0){alert('Add items first')} else setCheckoutOpen(true)}} className="px-4 py-2 rounded-2xl bg-emerald-600 text-white">Checkout</button>
            <a className="px-4 py-2 rounded-2xl border text-center" href={`https://wa.me/${WHATSAPP_NUM}?text=${encodeURIComponent('I want to order. Subtotal: '+currency(subtotal))}`} target="_blank">Order on WhatsApp</a>
          </div>
        </div>
      </div>

      {/* Checkout Modal */}
      {checkoutOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center">
          <div className="absolute inset-0 bg-black/50" onClick={()=>setCheckoutOpen(false)} />
          <form onSubmit={confirmOrder} className="relative bg-white rounded-2xl p-4 w-[95vw] max-w-xl">
            <h3 className="text-lg font-semibold">Checkout</h3>
            <div className="grid md:grid-cols-2 gap-2 mt-3">
              <input required placeholder="Customer Name" value={customer.name} onChange={e=>setCustomer({...customer,name:e.target.value})} className="p-2 border rounded"/>
              <input required type="email" placeholder="Email" value={customer.email} onChange={e=>setCustomer({...customer,email:e.target.value})} className="p-2 border rounded"/>
              <input required placeholder="Phone" value={customer.phone} onChange={e=>setCustomer({...customer,phone:e.target.value})} className="p-2 border rounded"/>
              <input required placeholder="Address" value={customer.address} onChange={e=>setCustomer({...customer,address:e.target.value})} className="p-2 border rounded"/>
            </div>
            <div className="mt-3">
              <label className="text-sm">Upload Payment Proof (UPI screenshot) — mandatory</label>
              <input required type="file" accept="image/*" onChange={handleFile} className="mt-1"/>
            </div>
            <div className="mt-4 flex gap-2">
              <button type="submit" className="px-4 py-2 bg-black text-white rounded">Confirm & Pay</button>
              <button type="button" onClick={()=>setCheckoutOpen(false)} className="px-4 py-2 border rounded">Cancel</button>
            </div>
          </form>
        </div>
      )}

    </div>
  )
}

// helper function for order ID (client-side)
function genOrderId(){
  return 'ORD' + Date.now().toString().slice(-6)
}
