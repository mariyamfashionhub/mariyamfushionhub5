
'use client'
import { useEffect, useState } from 'react'
import { useParams } from 'next/navigation'
import { SEED } from '../../_data/seed'
import { currency, WHATSAPP_NUM, UPI_ID } from '../../_utils/shop'

export default function ProductPage(){
  const params = useParams()
  const id = params.id
  const [product,setProduct] = useState(null)
  const [selected, setSelected] = useState({color:null, size:null})
  useEffect(()=>{
    const saved = localStorage.getItem('mf_products')
    const list = saved? JSON.parse(saved) : SEED
    setProduct(list.find(p=>p.id===id))
  },[id])

  if(!product) return <div className="p-6">Loading...</div>
  const color = selected.color || product.colors?.[0]?.name
  const size = selected.size || product.sizes?.[0]

  function addToCart(){
    const key = `${product.id}-${color}-${size}`
    const cart = JSON.parse(localStorage.getItem('mf_cart')||'[]')
    const found = cart.find(i=>i.key===key)
    if(found) found.qty += 1
    else cart.push({key, id:product.id, name:product.name, price:product.price, color, size, image: product.colors?.find(c=>c.name===color)?.image, qty:1})
    localStorage.setItem('mf_cart', JSON.stringify(cart))
    alert('Added to cart')
  }

  return (
    <div className="max-w-6xl mx-auto p-4">
      <div className="grid md:grid-cols-2 gap-6">
        <div>
          <img src={product.colors?.[0]?.image} className="w-full h-[420px] object-cover rounded" alt={product.name} />
          <div className="flex gap-2 mt-2">
            {product.colors.map(c=> <img key={c.name} src={c.image} className={`h-16 w-16 object-cover rounded border ${c.name===color?'ring-2 ring-black':''}`} onClick={()=>setSelected({...selected,color:c.name})} />)}
          </div>
        </div>
        <div>
          <h1 className="text-2xl font-bold">{product.name}</h1>
          <div className="mt-2">{currency(product.price)}</div>
          <p className="mt-3 text-slate-700">{product.description}</p>
          <div className="mt-3">
            <div className="text-sm mb-1">Choose Size</div>
            <div className="flex gap-2">{product.sizes.map(s=> <button key={s} onClick={()=>setSelected({...selected,size:s})} className={`px-3 py-2 rounded ${s===size?'bg-black text-white':'border'}`}>{s}</button>)}</div>
          </div>
          <div className="mt-4 grid grid-cols-2 gap-2">
            <button onClick={addToCart} className="px-4 py-2 bg-emerald-600 text-white rounded">Add to Cart</button>
            <a className="px-4 py-2 border rounded text-center" href={`https://wa.me/${WHATSAPP_NUM}?text=${encodeURIComponent('I want this product: '+product.name)}`} target="_blank">Order on WhatsApp</a>
          </div>
        </div>
      </div>
    </div>
  )
}
