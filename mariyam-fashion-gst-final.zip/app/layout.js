
import './globals.css'

export const metadata = {
  title: 'Mariyam Fashion & Kids Wear',
  description: 'Shop lehengas, sarees, kurtas & kids wear. Pay via UPI or order on WhatsApp.',
}

export default function RootLayout({ children }){
  return (
    <html lang="en">
      <body className="bg-slate-50">{children}</body>
    </html>
  )
}
